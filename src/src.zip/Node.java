public class Node
{
  public String data;
  public Node link;
}
